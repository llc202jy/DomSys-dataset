This is the supplementary material for the paper: Automated Domain Modeling with Large Language Models: A Comparative Study

- The file: __Modeling__ contains domain examples and their reference domain models.
- The folder: __llm-model-generation-master__ contains scripts for running large language models and post-processing the results. This folder contains another readme.md file and requirement.txt file for executing the scripts.
- The folder: __Problem Descriptions__ contains textual domain descriptions along with their graphical solutions.
- The folder: __Data analysis__ contains scripts for analyzing the experiment results. Note: the notebooks in this folder are developed and executed on Google Colab platform. Additionally, *_data_v4.csv*_ is the one used when reporting the results of the paper in the final_data_analysis.
- The folder: __experiments_result__ contains the results of each run on LLMs
- The folder: __Round 1 Evaluation__ contains evaluation of the generated domain models for the first round.
- The folder: __Round 2 Evaluation__ contains evaluation of the generated domain models for the second round. You may need to [enable macros in Excel](https://www.ablebits.com/office-addins-blog/enable-disable-macros-excel/#:~:text=Click%20the%20File%20tab%2C%20and%20then%20click%20Options%20at%20the,all%20macros%20and%20click%20OK.) in order to make sheets display data properly. 




## CC Attribution 4.0 International
```markdown
Shield: [![CC BY 4.0][cc-by-shield]][cc-by]

This work is licensed under a
[Creative Commons Attribution 4.0 International License][cc-by].

[![CC BY 4.0][cc-by-image]][cc-by]

[cc-by]: http://creativecommons.org/licenses/by/4.0/
[cc-by-image]: https://i.creativecommons.org/l/by/4.0/88x31.png
[cc-by-shield]: https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg
```

Shield: [![CC BY 4.0][cc-by-shield]][cc-by]

This work is licensed under a
[Creative Commons Attribution 4.0 International License][cc-by].

[![CC BY 4.0][cc-by-image]][cc-by]

[cc-by]: http://creativecommons.org/licenses/by/4.0/
[cc-by-image]: https://i.creativecommons.org/l/by/4.0/88x31.png
[cc-by-shield]: https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg