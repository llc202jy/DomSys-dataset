# Badges to apply

- __Reusable__: In this material we present the dataset of models together with the descriptions, the results of the manual evaluation, and the data analysis in the form of executable jupyter notebooks. This material can serve as a valuable benchmark for similar research activities on automating domain modeling by using LLMs. 

- __Available__: Our artifacts relevant to this paper have been placed on a publically accessible archival repository. 
    - DOI: 10.5281/zenodo.8118642
    - Link: https://zenodo.org/record/8118642
